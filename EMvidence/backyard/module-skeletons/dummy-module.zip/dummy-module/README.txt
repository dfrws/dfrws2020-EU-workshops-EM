This is a sample module that wraps an ML model.
