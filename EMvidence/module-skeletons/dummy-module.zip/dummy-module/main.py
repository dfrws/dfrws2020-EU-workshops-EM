
def initialize(config_settings):
    print("initialize() called.")
    
def preprocess(em_trace):
    print("preprocess() called.")
    
def classify():
    print("classify() called.")

def getResults(em_trace):
    print("getResults() called.")
    results = "Here's the results of the analysis.\n Classification accuracy: 99%"
    return results

def getConfusionMatrix():
    print("getConfusionMatrix() called.")